import { Route, Routes } from "react-router-dom";
import StepPersonalInfo from "./components/StepPersonalInfo";
import StepOTPVerification from "./components/StepOTPVerification";
import StepIDCardVerification from "./components/StepIDCardVerification";
import StepFaceVerification from "./components/StepFaceVerification";
import StepRegisterMethod from "./components/StepRegisterMethod";

const Register: React.FunctionComponent = () => {

  return (
    <div className="register-layout-wrapper">
      <div className="register-container">
        <div className="register-header">EWallet</div>
        <Routes>
          <Route path="" element={<StepRegisterMethod />} />
          <Route path="personal-information" element={<StepPersonalInfo />} />
          <Route path="otp-verification" element={<StepOTPVerification />} />
          <Route path="id-card-verification" element={<StepIDCardVerification />} />
          <Route path="face-verification" element={<StepFaceVerification />} />
        </Routes>
      </div>
    </div>
  );
}

export default Register;
