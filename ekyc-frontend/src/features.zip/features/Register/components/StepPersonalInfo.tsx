import TextInputField from "@/components/FormItems/TextInputField";
import SubmitButton from "@/components/Forms/SubmitButton";
import VerticalForm from "@/components/Forms/VerticalForm";
import { useForm } from "antd/lib/form/Form";

const StepPersonalInfo: React.FunctionComponent = () => {

  const [form] = useForm();

  return (
    <div className="register-form">
      <VerticalForm name="personal-info" form={form}>
        <TextInputField name="email" placeholder="Email" />
        <SubmitButton buttonClassName="submit-btn" name="Continue" />
      </VerticalForm>
    </div>
  );
}

export default StepPersonalInfo;