import FileInput from "@/components/Common/FileInput";
import { Icon } from "@iconify/react/dist/iconify.js";



const StepIDCardVerification: React.FunctionComponent = () => {
  return (
    <>
      <div className="text-center">
        <p>Upload ID Document</p>
        <div className="d-flex justify-content-evenly">
          <div>
            <FileInput>
              <div>
                <Icon icon="solar:user-id-linear" height={38} />
                <p>Front side</p>
              </div>
            </FileInput>
          </div>
          <div>
            <FileInput>
              <div>
                <Icon icon="solar:card-2-linear" height={38} />
                <p>Back side</p>
              </div>
            </FileInput>
          </div>
        </div>
      </div>
    </>
  )
}

export default StepIDCardVerification;