import FaceCapture from "@/components/Common/FaceCapture";

const StepFaceVerification: React.FunctionComponent = () => {
  return (
    <div className="text-center">
      <p>Enter OTP verification code</p>
      <div>
        <FaceCapture />
      </div>
    </div>
  )
}

export default StepFaceVerification;
