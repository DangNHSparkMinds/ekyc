import OTPInput from "@/components/Common/OTPInput";
import SubmitButton from "@/components/Forms/SubmitButton";

const StepOTPVerification: React.FunctionComponent = () => {
  return (
    <div className="text-center">
      <p>Enter OTP verification code</p>
      <div>
        <OTPInput inputClassName="otp-input" />
        <SubmitButton name="Verification" className="m-5" />
      </div>
    </div>
  )
}

export default StepOTPVerification;
