import authApi from "@/api/authApi";
import { RegisterByEmailRequest } from "@/models/auth";
import { useNavigate } from "react-router-dom";

const useRegister = () => {
  const navigate = useNavigate();

  const register = async (reqBody: RegisterByEmailRequest) => {
    const response = await authApi.register(reqBody);
    if (response.ok) {
      navigate("/otp-verification");
    }
  }

  return { register }
}

export default useRegister;