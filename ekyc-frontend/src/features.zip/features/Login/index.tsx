import React from "react";

const Login: React.FunctionComponent = () => {
  return (
    <>
      <div className="register-layout-wrapper">
        <div className="register-left">
        </div>
        <div className="register-form">
          <div className="register-form-header">EWallet</div>
          <div>
            <div className="d-grid">
              <span>Email</span>
              <input />
            </div>
            <div className="d-grid">
              <span>Password</span>
              <input />
            </div>
          </div>
          <div className="d-flex justify-content-around mt-5">
            <button className="btn-login">Login</button>
          </div>
        </div>
      </div>
    </>
  );
}

export default Login;